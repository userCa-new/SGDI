<?php

namespace Source\Models;

use PDO;
use Source\Core\Model;
use Source\Core\Connect;
use Source\Core\JWTToken;

class User extends Model
{
    private ?int $idUser;
    private ?int $idUserType;
    private ?string $name;
    private ?string $email;
    private ?string $password;
    private ?string $active;

    private ?string $token = null;

    public function __construct(
        ?int $idUser = null,
        ?int $idUserType = null,
        ?string $name = null,
        ?string $email = null,
        ?string $password = null,
    ) {
        $this->idUser = $idUser;
        $this->idUserType = $idUserType;
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;

        $this->table = "users"; // nome da tabela do banco
        $this->primaryKey = "id_user"; // nome da chave primária da tabela
        $this->fillable = ["idUserType", "name", "email", "password"]; // camelCase
    }

    public function getIdUser(): ?int
    {
        return $this->idUser;
    }

    public function setIdUser(?int $idUser): void
    {
        $this->idUser = $idUser;
    }

    public function getIdUserType(): ?int
    {
        return $this->idUserType;
    }

    public function setIdUserType(?int $idUserType): void
    {
        $this->idUserType = $idUserType;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(?string $email): void
    {
        $this->email = $email;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(?string $password): void
    {
        $this->password = $password;
    }

    public function getToken(): ?string
    {
        return $this->token;
    }

    public function insert(): bool
    {
        $query = "SELECT * FROM {$this->table} WHERE email = :email";
        $stmt = Connect::getInstance()->prepare($query);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            $this->errorMessage = "Email já cadastrado";
            return false;
        }
        $this->password = password_hash($this->password, PASSWORD_DEFAULT);

        if (!parent::insert()) {
            $this->errorMessage = "Algo deu errado";
            return false;
        }
        return true;
    }

    public function login(string $email, string $password): bool
    {
        $query = "SELECT * FROM {$this->table} WHERE email = :email";
        $stmt = Connect::getInstance()->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();

        if ($stmt->rowCount() == 0) {
            $this->errorMessage = "Email não cadastrado";
            return false;
        }

        $user = $stmt->fetch();

        if (!password_verify($password, $user->password)) {
            $this->errorMessage = "Senha incorreta";
            return false;
        }

        $this->idUser = $user->id_user;
        $this->idUserType = $user->id_user_type;
        $this->name = $user->name;
        $this->email = $user->email;

        $jwt = new JWTToken();
        $this->token = $jwt->encode([
            "id" => $user->id_user,
            "name" => $user->name,
            "email" => $user->email,
        ]);

        return true;
    }

    public function permissionVerify(string $email, int $typeId): bool
    {
        $query = "SELECT *
              FROM users
              WHERE email = :email
              AND id_user_type = :typeId";

        $stmt = Connect::getInstance()->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":typeId", $typeId);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }
}
