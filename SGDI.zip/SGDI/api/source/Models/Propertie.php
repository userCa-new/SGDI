<?php

namespace Source\Models;

use Source\Core\Model;
use Source\Core\Connect;
use PDOException;

class Propertie extends Model
{
    protected ?int $idProperty;
    protected ?int $idUser;
    protected ?string $location;
    protected ?int $numberOfRooms;
    protected ?int $availability;
    protected ?int $latePayment;

    public function __construct(
        ?int $idProperty = null,
        ?int $idUser = null,
        ?string $location = null,
        ?int $numberOfRooms = null,
        ?int $availability = null,
        ?int $latePayment = null,
    ) {
        $this->idProperty = $idProperty;
        $this->idUser = $idUser;
        $this->location = $location;
        $this->numberOfRooms = $numberOfRooms;
        $this->availability = $availability;
        $this->latePayment = $latePayment;

        $this->table = "properties";
        $this->primaryKey = "id_property";
        $this->fillable = [
            "idUser",
            "location",
            "numberOfRooms",
            "availability",
            "latePayment",
        ];
    }

    public function getIdProperty(): ?int
    {
        return $this->idProperty;
    }

    public function setIdProperty(?int $idProperty): void
    {
        $this->idProperty = $idProperty;
    }

    public function getIdUser(): ?int
    {
        return $this->idUser;
    }

    public function setIdUser(?int $idUser): void
    {
        $this->idUser = $idUser;
    }

    public function getLocation(): ?string
    {
        return $this->location;
    }

    public function setLocation(?string $location): void
    {
        $this->location = $location;
    }

    public function getNumberOfRooms(): ?int
    {
        return $this->numberOfRooms;
    }

    public function setNumberOfRooms(?int $numberOfRooms): void
    {
        $this->numberOfRooms = $numberOfRooms;
    }

    public function getAvailability(): ?int
    {
        return $this->availability;
    }

    public function setAvailability(?int $availability): void
    {
        $this->availability = $availability;
    }

    public function getLatePayment(): ?int
    {
        return $this->latePayment;
    }

    public function setLatePayment(?int $latePayment): void
    {
        $this->latePayment = $latePayment;
    }
    public function deleteById(int $id): bool
    {
        try {
            $query = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id";
            $stmt = Connect::getInstance()->prepare($query);
            $stmt->bindValue(":id", $id);
            $stmt->execute();
            if ($stmt->rowCount() < 1) {
                $this->errorMessage = "Registro não encontrado ou inativo.";
                return false;
            }
            return true;
        } catch (PDOException $e) {
            $this->errorMessage = $e->getMessage();
            return false;
        }
    }
}
