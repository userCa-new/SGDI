const paymentList = document.getElementById("payment-list");
const toast = document.getElementById("toast");
const scheduleForm = document.getElementById("schedule-form");
const scheduleDisplay = document.getElementById("schedule-display");
const chatWindow = document.getElementById("owner-chat-window");
const ownerChatForm = document.getElementById("owner-chat-form");
const ownerChatProperty = document.getElementById("owner-chat-property");

const savedPayments = JSON.parse(localStorage.getItem("ownerPayments") || "[]");
const chatMessages = JSON.parse(localStorage.getItem("chatMessages") || "[]");
let lastConfirmedPayment = null;
let toastTimeout = null;

const paymentPanel = document.querySelector(".pix-panel");
const paymentMethodsContainer = document.createElement("div");
paymentMethodsContainer.className = "payment-methods";
if (paymentPanel) {
  const pixList = paymentPanel.querySelector(".pix-list");
  if (pixList) {
    paymentPanel.insertBefore(paymentMethodsContainer, pixList);
  }
}

function getPaymentMethods() {
  return JSON.parse(localStorage.getItem("ownerPaymentMethods") || "[]");
}

function savePaymentMethods(methods) {
  localStorage.setItem("ownerPaymentMethods", JSON.stringify(methods));
}

function renderPaymentMethods() {
  const methods = getPaymentMethods();

  if (!paymentMethodsContainer) return;

  if (!methods.length) {
    paymentMethodsContainer.innerHTML =
      '<p class="hint">Nenhum método fixado. Clique em "Fixar método de pagamento" para adicionar Pix, QR Code ou dados bancários.</p>';
    return;
  }

  paymentMethodsContainer.innerHTML = methods
    .map((method) => {
      return `
            <article class="payment-card">
                <p class="method-type">${method.type}</p>
                <p class="method-value">${method.value}</p>
                ${method.qrDataUrl ? `<img src="${method.qrDataUrl}" alt="QR Code de ${method.type}" />` : ""}
            </article>
        `;
    })
    .join("");
}

function createPaymentModal() {
  const modal = document.createElement("div");
  modal.className = "modal-backdrop";
  modal.hidden = true;
  modal.setAttribute("aria-hidden", "true");

  modal.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="payment-modal-title">
      <header class="modal-header">
        <div>
          <p class="eyebrow">Cobranças</p>
          <h2 id="payment-modal-title">Configurar método de cobrança</h2>
        </div>
        <button type="button" class="modal-close" id="payment-modal-close" aria-label="Fechar modal">×</button>
      </header>

      <form id="payment-method-form" class="payment-method-form">
        <label for="payment-type">Tipo de cobrança</label>
        <select id="payment-type" required>
          <option value="Pix">Pix</option>
          <option value="QR Code">QR Code</option>
          <option value="Banco">Banco</option>
        </select>

        <label for="payment-value">Chave ou dados</label>
        <input id="payment-value" type="text" placeholder="Digite a chave Pix, QR ou dados bancários" required />

        <div class="qr-input-group" hidden>
          <label for="qr-file">Anexar QR Code</label>
          <input id="qr-file" type="file" accept="image/*" />
        </div>

        <div class="qr-preview" id="qr-preview" hidden>
          <p class="label">Prévia do QR Code</p>
          <img id="qr-image-preview" alt="Prévia do QR Code" />
        </div>

        <div class="modal-actions">
          <button type="button" class="button-secondary" id="payment-modal-cancel">Cancelar</button>
          <button type="submit" class="confirm-button">Salvar cobrança</button>
        </div>
      </form>
    </div>
  `;

  const form = modal.querySelector("#payment-method-form");
  const closeButton = modal.querySelector("#payment-modal-close");
  const cancelButton = modal.querySelector("#payment-modal-cancel");
  const fileGroup = modal.querySelector(".qr-input-group");
  const fileInput = modal.querySelector("#qr-file");
  const qrPreview = modal.querySelector("#qr-preview");
  const qrImagePreview = modal.querySelector("#qr-image-preview");
  const paymentType = modal.querySelector("#payment-type");
  const paymentValue = modal.querySelector("#payment-value");

  function closeModal() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    form.reset();
    fileGroup.hidden = true;
    qrPreview.hidden = true;
    qrImagePreview.src = "";
  }

  function openModal() {
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    paymentValue.focus();
  }

  function toggleQrInput() {
    const isQr = paymentType.value === "QR Code";
    fileGroup.hidden = !isQr;
    if (!isQr) {
      fileInput.value = "";
      qrPreview.hidden = true;
      qrImagePreview.src = "";
    }
  }

  paymentType.addEventListener("change", toggleQrInput);
  toggleQrInput();

  fileInput.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file || !file.type.startsWith("image/")) {
      qrPreview.hidden = true;
      qrImagePreview.src = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      qrImagePreview.src = reader.result;
      qrPreview.hidden = false;
    };
    reader.readAsDataURL(file);
  });

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });

  closeButton.addEventListener("click", closeModal);
  cancelButton.addEventListener("click", closeModal);

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const methods = getPaymentMethods();
    const newMethod = {
      type: paymentType.value,
      value: paymentValue.value.trim(),
      qrDataUrl:
        paymentType.value === "QR Code" ? qrImagePreview.src || "" : "",
      createdAt: new Date().toISOString(),
    };

    methods.unshift(newMethod);
    savePaymentMethods(methods);
    renderPaymentMethods();
    closeModal();
  });

  return { modal, openModal };
}

const paymentModal = createPaymentModal();
document.body.appendChild(paymentModal.modal);
renderPaymentMethods();

const paymentMethodButton = document.getElementById("manage-payment-method");
if (paymentMethodButton) {
  paymentMethodButton.addEventListener("click", () => {
    paymentModal.openModal();
  });
}

function renderPaymentList() {
  if (!savedPayments.length) {
    paymentList.innerHTML =
      '<p class="hint">Nenhum pagamento registrado. Aguarde confirmações assistidas.</p>';
    return;
  }

  paymentList.innerHTML = savedPayments
    .map((payment, index) => {
      return `
            <article class="payment-item">
                <header>
                    <div>
                        <strong>${payment.tenant}</strong>
                        <p>${payment.status}</p>
                    </div>
                    <div style="display:flex;gap:8px;align-items:center">
                      <button class="button-secondary show-proof" data-tenant="${payment.tenant}">Comprovante</button>
                      <button class="confirm-button" data-index="${index}">${payment.status.toLowerCase().includes("confirmado") ? "Confirmado" : "Confirmar"}</button>
                    </div>
                </header>
                <p>Valor: ${payment.amount}</p>
                <p>Vencimento: ${payment.due}</p>
            </article>
        `;
    })
    .join("");
}

function getPaymentProofs() {
  return JSON.parse(localStorage.getItem("paymentProofs") || "[]");
}

function createOwnerProofModal() {
  const modal = document.createElement("div");
  modal.className = "modal-backdrop";
  modal.hidden = true;
  modal.setAttribute("aria-hidden", "true");

  modal.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="owner-proof-title">
      <header class="modal-header">
        <div>
          <p class="eyebrow">Comprovante</p>
          <h2 id="owner-proof-title">Comprovante do inquilino</h2>
        </div>
        <button type="button" class="modal-close" id="owner-proof-close" aria-label="Fechar">×</button>
      </header>
      <div class="modal-body" id="owner-proof-body">
      </div>
      <div class="modal-actions">
        <button type="button" class="button-secondary" id="owner-proof-download">Fechar</button>
      </div>
    </div>
  `;

  const body = modal.querySelector("#owner-proof-body");
  const closeBtn = modal.querySelector("#owner-proof-close");
  const closeAction = modal.querySelector("#owner-proof-download");

  function openFor(tenant) {
    body.innerHTML = "";
    const proofs = getPaymentProofs().filter(
      (p) =>
        p.reference && p.reference.toLowerCase().includes(tenant.toLowerCase()),
    );
    if (!proofs.length) {
      body.innerHTML =
        '<p class="hint">Nenhum comprovante encontrado para este pagamento.</p>';
    } else {
      body.innerHTML = proofs
        .map((p) => {
          return `
            <article class="payment-card">
              <p class="method-type">Referência: ${p.reference}</p>
              <p class="method-value">Valor: ${p.amount || "—"}</p>
              ${p.fileType && p.fileType.startsWith("image/") ? `<img src="${p.dataUrl}" alt="comprovante"/>` : p.fileType === "application/pdf" ? `<p><a href="${p.dataUrl}" download="${p.fileName}">Baixar PDF</a></p>` : `<p class="hint">Comprovante recebido (sem arquivo)</p>`}
              <p class="muted">Enviado em ${new Date(p.createdAt).toLocaleString("pt-BR")}</p>
            </article>
          `;
        })
        .join("");
    }

    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function close() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  modal.addEventListener("click", (ev) => {
    if (ev.target === modal) close();
  });

  closeBtn.addEventListener("click", close);
  closeAction.addEventListener("click", close);

  return { modal, openFor };
}

const ownerProofModal = createOwnerProofModal();
document.body.appendChild(ownerProofModal.modal);

function getOwnerProperties() {
  return JSON.parse(localStorage.getItem("ownerProperties") || "[]");
}

function saveOwnerProperties(properties) {
  localStorage.setItem("ownerProperties", JSON.stringify(properties));
}

function createPropertyFormModal() {
  const modal = document.createElement("div");
  modal.className = "modal-backdrop";
  modal.hidden = true;
  modal.setAttribute("aria-hidden", "true");

  modal.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="property-form-title">
      <header class="modal-header">
        <div>
          <p class="eyebrow">Adicionar imóvel</p>
          <h2 id="property-form-title">Cadastrar ou atualizar imóvel</h2>
        </div>
        <button type="button" class="modal-close" id="property-form-close" aria-label="Fechar">×</button>
      </header>
      <form id="property-form" class="payment-method-form">
        <label for="property-location">Localização</label>
        <input id="property-location" type="text" placeholder="Rua / Bairro / Cidade" required />

        <label for="property-tenants">Quantidade de inquilinos</label>
        <input id="property-tenants" type="number" min="0" placeholder="0" required />

        <label for="property-overdue">Atrasado</label>
        <select id="property-overdue">
          <option value="false">Não</option>
          <option value="true">Sim</option>
        </select>

        <label for="property-vacant">Vago</label>
        <select id="property-vacant">
          <option value="false">Não</option>
          <option value="true">Sim</option>
        </select>

        <div class="modal-actions">
          <button type="button" class="button-secondary" id="property-form-cancel">Cancelar</button>
          <button type="submit" class="confirm-button">Salvar imóvel</button>
        </div>
      </form>
    </div>
  `;

  const form = modal.querySelector("#property-form");
  const closeButton = modal.querySelector("#property-form-close");
  const cancelButton = modal.querySelector("#property-form-cancel");
  const locationInput = modal.querySelector("#property-location");
  const tenantsInput = modal.querySelector("#property-tenants");
  const overdueSelect = modal.querySelector("#property-overdue");
  const vacantSelect = modal.querySelector("#property-vacant");
  let currentIndex = null;

  function open(property = null, index = null) {
    currentIndex = index;
    if (property) {
      locationInput.value = property.location;
      tenantsInput.value = property.tenants;
      overdueSelect.value = property.overdue ? "true" : "false";
      vacantSelect.value = property.vacant ? "true" : "false";
    } else {
      form.reset();
    }
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    locationInput.focus();
  }

  function close() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    currentIndex = null;
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const properties = getOwnerProperties();
    const propertyData = {
      location: locationInput.value.trim(),
      tenants: Number(tenantsInput.value),
      overdue: overdueSelect.value === "true",
      vacant: vacantSelect.value === "true",
      updatedAt: new Date().toISOString(),
    };

    if (currentIndex !== null) {
      properties[currentIndex] = propertyData;
    } else {
      properties.unshift(propertyData);
    }
    saveOwnerProperties(properties);
    close();
    if (propertiesModal) {
      propertiesModal.refresh();
    }
    renderChatPropertyOptions();
  });

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      close();
    }
  });
  closeButton.addEventListener("click", close);
  cancelButton.addEventListener("click", close);

  return { modal, open };
}

function createPropertiesModal() {
  const modal = document.createElement("div");
  modal.className = "modal-backdrop";
  modal.hidden = true;
  modal.setAttribute("aria-hidden", "true");

  modal.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="properties-title">
      <header class="modal-header">
        <div>
          <p class="eyebrow">Imóveis</p>
          <h2 id="properties-title">Meus imóveis</h2>
        </div>
        <button type="button" class="button-secondary" id="add-property-button" aria-label="Adicionar imóvel">+</button>
      </header>
      <div class="properties-grid" id="properties-grid"></div>
      <div class="modal-actions">
        <button type="button" class="button-secondary" id="properties-close">Fechar</button>
      </div>
    </div>
  `;

  const grid = modal.querySelector("#properties-grid");
  const closeButton = modal.querySelector("#properties-close");
  const addButton = modal.querySelector("#add-property-button");

  function renderList() {
    const properties = getOwnerProperties();
    if (!properties.length) {
      grid.innerHTML =
        '<p class="hint">Nenhum imóvel cadastrado ainda. Adicione um usando o botão +.</p>';
      return;
    }
    grid.innerHTML = properties
      .map((property, index) => {
        return `
          <article class="property-card">
            <div class="property-card-header">
              <div>
                <p class="method-type">Localização</p>
                <p class="method-value">${property.location}</p>
              </div>
              <div class="property-badges">
                <span class="badge ${property.overdue ? "badge-danger" : "badge-success"}">${property.overdue ? "Atrasado" : "Em dia"}</span>
                <span class="badge ${property.vacant ? "badge-warning" : "badge-info"}">${property.vacant ? "Vago" : "Ocupado"}</span>
              </div>
            </div>
            <div class="property-grid">
              <div>
                <p class="method-type">Inquilinos</p>
                <p class="method-value">${property.tenants}</p>
              </div>
            </div>
            <div class="property-card-actions">
              <button type="button" class="confirm-button update-property" data-index="${index}">Atualizar</button>
              <button type="button" class="button-secondary remove-property" data-index="${index}">Remover</button>
            </div>
          </article>
        `;
      })
      .join("");
  }

  function open() {
    renderList();
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function close() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      close();
    }
  });

  closeButton.addEventListener("click", close);
  addButton.addEventListener("click", () => {
    if (propertyFormModal) {
      close();
      propertyFormModal.open();
    }
  });

  grid.addEventListener("click", (event) => {
    const updateButton = event.target.closest(".update-property");
    if (updateButton) {
      const index = Number(updateButton.dataset.index);
      if (Number.isNaN(index)) return;
      const properties = getOwnerProperties();
      const property = properties[index];
      if (propertyFormModal) {
        close();
        propertyFormModal.open(property, index);
      }
      return;
    }

    const removeButton = event.target.closest(".remove-property");
    if (removeButton) {
      const index = Number(removeButton.dataset.index);
      if (Number.isNaN(index)) return;
      const properties = getOwnerProperties();
      properties.splice(index, 1);
      saveOwnerProperties(properties);
      renderList();
      renderChatPropertyOptions();
    }
  });

  return { modal, open, refresh: renderList };
}

const propertyFormModal = createPropertyFormModal();
document.body.appendChild(propertyFormModal.modal);

const propertiesModal = createPropertiesModal();
document.body.appendChild(propertiesModal.modal);

const ownerPropertiesButton = document.getElementById(
  "owner-properties-button",
);
if (ownerPropertiesButton) {
  ownerPropertiesButton.addEventListener("click", () => {
    propertiesModal.open();
  });
}

paymentList.addEventListener("click", (ev) => {
  const btn = ev.target.closest(".show-proof");
  if (!btn) return;
  const tenant = btn.dataset.tenant;
  ownerProofModal.openFor(tenant);
});

function getTenantIssues() {
  return JSON.parse(localStorage.getItem("tenantIssues") || "[]");
}

function saveTenantIssues(issues) {
  localStorage.setItem("tenantIssues", JSON.stringify(issues));
}

function renderOwnerIssues() {
  const container = document.querySelector(".issues-panel .issue-list");
  if (!container) return;

  const issues = getTenantIssues();
  if (!issues.length) {
    container.innerHTML =
      "<li>Nenhuma solicitação de manutenção pendente.</li>";
    return;
  }

  container.innerHTML = issues
    .map((issue) => {
      return `
            <li data-created="${issue.createdAt}">
                <strong>${issue.type}</strong>
                <p>${issue.details}</p>
                <time>Enviado em ${new Date(issue.createdAt).toLocaleString("pt-BR")}</time>
                <div style="margin-top:8px">
                  <button class="confirm-button issue-complete" data-created="${issue.createdAt}">Marcar como concluído</button>
                </div>
            </li>
        `;
    })
    .join("");
}

document.addEventListener("click", (event) => {
  const btn = event.target.closest(".issue-complete");
  if (!btn) return;
  const createdAt = btn.dataset.created;
  if (!createdAt) return;

  const issues = getTenantIssues();
  const remaining = issues.filter((i) => i.createdAt !== createdAt);
  saveTenantIssues(remaining);
  renderOwnerIssues();

  const removed = issues.find((i) => i.createdAt === createdAt);
  if (removed) {
    localStorage.setItem(
      "lastMaintenanceCompleted",
      JSON.stringify({ removed, completedAt: new Date().toISOString() }),
    );
  }

  showToast("Solicitação marcada como concluída.", () => {
    if (!removed) return;
    remaining.unshift(removed);
    saveTenantIssues(remaining);

    localStorage.removeItem("lastMaintenanceCompleted");
    renderOwnerIssues();
  });
});

function savePayments() {
  localStorage.setItem("ownerPayments", JSON.stringify(savedPayments));
}

function saveChatMessages() {
  localStorage.setItem("chatMessages", JSON.stringify(chatMessages));
}

function renderChat() {
  if (!chatMessages.length) {
    chatWindow.innerHTML =
      "<p>Inicie a conversa com o inquilino usando o formulário abaixo.</p>";
    chatWindow.scrollTop = chatWindow.scrollHeight;
    return;
  }

  chatWindow.innerHTML = chatMessages
    .map((message) => {
      return `
            <article class="chat-message ${message.from}">
                ${message.property ? `<p class="chat-property">Imóvel: ${message.property}</p>` : ""}
                <p>${message.text}</p>
                <time>${new Date(message.createdAt).toLocaleTimeString("pt-BR")}</time>
            </article>
        `;
    })
    .join("");

  chatWindow.scrollTop = chatWindow.scrollHeight;
  adjustChatScrolling(chatWindow);
}

function adjustChatScrolling(container) {
  if (!container) return;
  const messages = container.querySelectorAll(".chat-message");
  if (messages.length > 3) {
    container.style.maxHeight = "320px";
    container.style.overflowY = "auto";
  } else {
    container.style.maxHeight = "";
    container.style.overflowY = "";
  }
}

function renderChatPropertyOptions() {
  if (!ownerChatProperty) return;

  const properties = getOwnerProperties();
  if (!properties.length) {
    ownerChatProperty.innerHTML =
      '<option value="">Nenhum imóvel cadastrado</option>';
    ownerChatProperty.disabled = true;
    return;
  }

  ownerChatProperty.disabled = false;
  ownerChatProperty.innerHTML =
    '<option value="">Selecionar imóvel</option>' +
    properties
      .map(
        (property, index) =>
          `<option value="${index}">${property.location}</option>`,
      )
      .join("");
}

function renderAppointment() {
  const appointment = JSON.parse(
    localStorage.getItem("ownerAppointment") || "null",
  );

  if (!appointment) {
    scheduleDisplay.textContent = "Nenhum agendamento definido.";
    return;
  }

  scheduleDisplay.textContent =
    `${appointment.date} às ${appointment.time}` +
    (appointment.note ? ` — ${appointment.note}` : "");
}

function showToast(message, onUndo) {
  if (!toast) return;

  toast.innerHTML = `
        <p>${message}</p>
        <button type="button" class="toast-action">Desfazer</button>
    `;
  toast.classList.add("show");

  const action = toast.querySelector(".toast-action");
  if (action) {
    action.addEventListener(
      "click",
      () => {
        if (onUndo) {
          onUndo();
        }
        toast.classList.remove("show");
        toast.innerHTML = "";
        clearTimeout(toastTimeout);
      },
      { once: true },
    );
  }

  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove("show");
    toast.innerHTML = "";
  }, 6000);
}

paymentList.addEventListener("click", (event) => {
  const button = event.target.closest(".confirm-button");
  if (!button) {
    return;
  }

  const index = Number(button.dataset.index);
  if (Number.isNaN(index)) {
    return;
  }

  const confirmedPayment = savedPayments.splice(index, 1)[0];
  savePayments();

  localStorage.setItem(
    "lastPaymentConfirmed",
    JSON.stringify({
      tenant: confirmedPayment.tenant,
      amount: confirmedPayment.amount,
      due: confirmedPayment.due,
      confirmedAt: new Date().toISOString(),
    }),
  );

  lastConfirmedPayment = {
    payment: confirmedPayment,
    index,
  };

  renderPaymentList();
  showToast(`Pagamento de ${confirmedPayment.tenant} confirmado.`, () => {
    if (!lastConfirmedPayment) return;
    savedPayments.splice(
      lastConfirmedPayment.index,
      0,
      lastConfirmedPayment.payment,
    );
    savePayments();
    renderPaymentList();
    lastConfirmedPayment = null;
  });
});

if (!savedPayments.length) {
  const samplePayments = [
    {
      tenant: "Apartamento 201",
      amount: "R$ 1.680,00",
      due: "07/06",
      status: "Pendente, confirme no banco",
    },
    {
      tenant: "Apartamento 110",
      amount: "R$ 1.320,00",
      due: "10/06",
      status: "Em análise",
    },
    {
      tenant: "Apartamento 304",
      amount: "R$ 1.940,00",
      due: "12/06",
      status: "Pendente, aguardando comprovante",
    },
  ];
  savedPayments.push(...samplePayments);
  savePayments();
}

if (scheduleForm) {
  scheduleForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const appointment = {
      date: document.getElementById("schedule-date").value,
      time: document.getElementById("schedule-time").value,
      note: document.getElementById("schedule-note").value.trim(),
      createdAt: new Date().toISOString(),
    };

    localStorage.setItem("ownerAppointment", JSON.stringify(appointment));
    renderAppointment();
    alert("Agendamento salvo e disponível para o inquilino.");
    scheduleForm.reset();
  });
}

if (ownerChatForm) {
  ownerChatForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const messageText = document
      .getElementById("owner-chat-message")
      .value.trim();
    if (!messageText) {
      return;
    }

    let propertyValue = null;
    if (ownerChatProperty && ownerChatProperty.value !== "") {
      const index = Number(ownerChatProperty.value);
      const property = getOwnerProperties()[index];
      propertyValue = property ? property.location : null;
    }

    chatMessages.push({
      from: "owner",
      text: messageText,
      property: propertyValue,
      createdAt: new Date().toISOString(),
    });

    saveChatMessages();
    renderChat();
    ownerChatForm.reset();
  });
}

renderPaymentList();
renderAppointment();
renderChatPropertyOptions();
renderChat();
renderOwnerIssues();

//a
